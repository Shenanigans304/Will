﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using ShoppingCart.DataAccess.Data;
using ShoppingCart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart.DataAccess.Repositories
{
    public class CartRepo : Repository<Cart>, ICartRepository
    {
        private ApplicationDbContext _context;
        public CartRepo(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }

        public void Update(Cart Cart)
        {
            var cartDB = _context.Carts.FirstOrDefault(x => x.Id == Cart.Id);
            if (cartDB != null)
            {
                cartDB.Product = Cart.Product;
                cartDB.ApplicationUser = Cart.ApplicationUser;
                cartDB.Count = Cart.Count;
                
            }
        }

        public void IncrementCartItem(Cart cart)
        {
            var cartDB = _context.Carts.FirstOrDefault(x => x.Id == cart.Id);
            
                if (cart.Count >= 1)
                {
                _context.Category.Add(vm.Category);
                    TempData["success"] = "Category Updated Done!";
                }
                
              
        }




    }
}
